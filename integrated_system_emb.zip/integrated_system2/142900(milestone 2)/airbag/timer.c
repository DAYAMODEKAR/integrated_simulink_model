#include <avr/io.h>
#include "timer.h"
void timer_start()
{
    TCNT0=0x00;
    TCCR0A=0x00;
    TCCR0B |= ((1<<CS00)|(1<<CS01));
    Set_Bit(TIMSK0,TOIE0);

}
