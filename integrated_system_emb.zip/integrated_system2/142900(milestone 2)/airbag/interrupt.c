
#include "interrupt.h"
void Switches()
{
    Set_Bit(SREG,7);

    Set_Bit(PCICR,PCIE1);
    Set_Bit(PCMSK1,PCINT14); // Engine ON Interrupt

    Set_Bit(PCICR,PCIE2);
    Set_Bit(PCMSK2,PCINT20); // Engine OFF Interrupt



}

