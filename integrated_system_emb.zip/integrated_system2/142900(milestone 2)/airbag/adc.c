#include "Adc.h"
void adc()
{


    Clr_Bit(ADMUX,MUX0);
    Clr_Bit(ADMUX,MUX1);
    Clr_Bit(ADMUX,MUX2);
    Clr_Bit(ADMUX,MUX3);
    Clr_Bit(ADMUX,ADLAR);
    Clr_Bit(ADMUX,REFS0);
    Clr_Bit(ADMUX,REFS1);
    Set_Bit(ADCSRA,ADEN);

}
void adc_read()
{
    Set_Bit(ADCSRA,ADSC);
    while(ADSC==1);
    adc_value1=ADC;

   }

void adc3()
{
    Clr_Bit(ADMUX,MUX0);
    Set_Bit(ADMUX,MUX1);
    Clr_Bit(ADMUX,MUX2);
    Clr_Bit(ADMUX,MUX3);
    Clr_Bit(ADMUX,ADLAR);
    Clr_Bit(ADMUX,REFS0);
    Clr_Bit(ADMUX,REFS1);
    Set_Bit(ADCSRA,ADEN);
}

void adc_start3()
{
    Set_Bit(ADCSRA,ADSC);
    while(ADSC==1);
    adc_value3=ADC;
}
