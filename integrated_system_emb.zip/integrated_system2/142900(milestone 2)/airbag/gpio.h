#ifndef GPIO_H_INCLUDED
#define GPIO_H_INCLUDED
#include "HeaderKing.h"
void inputs();


#endif // GPIO_H_INCLUDED

