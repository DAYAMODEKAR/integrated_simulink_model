
void GPIO_setting_Init(void);

