
#include <avr/io.h>

#include "PM_AdC.h"

#define SET_BIT(PORT,PIN) PORT|=(1<<PIN)

#define CLR_BIT(PORT,PIN) PORT&=~(1<<PIN)

void ADC_init()

{
    SET_BIT(ADMUX,MUX0);//select channel 5
    CLR_BIT(ADMUX,MUX1);
    SET_BIT(ADMUX,MUX2);
    CLR_BIT(ADMUX,MUX3);


    SET_BIT(ADCSRA,ADEN);

    CLR_BIT(DDRC,PC5);   // this will be the input from pressure sensor

}



int READ_ADC()

{

    SET_BIT(ADCSRA,ADSC);
    while(ADCSRA & (1<<ADSC));


   return ADC;

}
