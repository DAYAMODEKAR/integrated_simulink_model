
#ifndef PWM_H_INCLUDED
#define PWM_H_INCLUDED
#include "HeaderKing.h"
#define SetPWM(value) OCR0A = value
void HeadIntensity();

#endif // PWM_H_INCLUDED
