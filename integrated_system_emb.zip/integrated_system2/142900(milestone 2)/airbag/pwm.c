
#include "PWM.h"
void HeadIntensity()
{
    TCNT0=0x00;

    Set_Bit(TCCR0A,WGM00); // Fast PWM Mode
    Set_Bit(TCCR0A,WGM01);
    Clr_Bit(TCCR0B,WGM02);

    Set_Bit(TCCR0A,COM0A1); // Clear OC0A on compare match
    Set_Bit(TCCR0B,CS00); // Pre-scaler OF 1024

    Clr_Bit(TCCR0B,CS01);
    Set_Bit(TCCR0B,CS02);
}

