
#include "GPIO.h"
void inputs()
{
    Clr_Bit(DDRC,PC6); // Engine ON
    Clr_Bit(DDRD,PD4); // Engine OFF

    Set_Bit(DDRD,PD6); // impact level detection
    Set_Bit(DDRB,PB5); // Airbag  system

    Clr_Bit(PORTD,PD6);
    Clr_Bit(PORTB,PB5);

    Set_Bit(DDRB,PB0);//Seat belt tensioner
    Clr_Bit(PORTB,PB0);


    Set_Bit(DDRB,PB2); //seat belt not used status Led
    Clr_Bit(PORTB,PB2);

    Set_Bit(DDRD,PD7) ;//led indication for door operation
    Clr_Bit(PORTD,PD7);

    Clr_Bit(DDRD,PD2);//battery status switch
    Set_Bit(PORTD,PD2);

}
