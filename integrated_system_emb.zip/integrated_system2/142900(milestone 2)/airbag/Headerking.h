#ifndef HEADERKING_H_INCLUDED
#define HEADERKING_H_INCLUDED
#include <avr/io.h>
#include <avr/interrupt.h>

#define Set_Bit(PORT,BIT) PORT |=(1<<BIT)
#define Clr_Bit(PORT,BIT) PORT &=~(1<<BIT)
#define Toggle(PORT,BIT) PORT ^=(1<<BIT)
#define READ_BIT(PORT,BIT) PORT&=~(1<<BIT)
struct
{
unsigned int on:1;
unsigned int off:1;
unsigned int adc_value;
unsigned int door:1;
}air_s;
unsigned int adc_value3;
unsigned int adc_value1;


#endif // HEADERKING_H_INCLUDED

