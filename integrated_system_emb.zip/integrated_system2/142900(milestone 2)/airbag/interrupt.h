#ifndef INTERRUPT_H_INCLUDED
#define INTERRUPT_H_INCLUDED
#include "HeaderKing.h"
void Switches();

#endif // INTERRUPT_H_INCLUDED

