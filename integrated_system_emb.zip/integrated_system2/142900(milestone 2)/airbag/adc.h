
#ifndef ADC_H_INCLUDED
#define ADC_H_INCLUDED
#include "HeaderKing.h"
#define ADCON Set_Bit(ADCSRA,ADEN)
#define ADCOFF Clr_Bit(ADCSRA,ADEN)

void adc();
void adc_read();
void adc_start3();
void adc3();
#endif // ADC_H_INCLUDED

