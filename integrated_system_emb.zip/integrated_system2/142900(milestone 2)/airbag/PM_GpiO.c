
#include "PM_GpiO.h"

#include <avr/io.h>
#define SET_BIT(PORT,PIN) PORT|=(1<<PIN)

#define CLR_BIT(PORT,PIN) PORT&=~(1<<PIN)



void GPIO_setting_Init(void)

{
     SET_BIT(DDRB,PB7);//OUTLET VALVE
     SET_BIT(DDRB,PB6);//INPUT VALVE
     CLR_BIT(PORTB,PB7);
     CLR_BIT(PORTB,PB6);
}


