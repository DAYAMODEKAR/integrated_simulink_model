/*
Integrated embedded code
EMP ID:142900
       142923
       142924
       142925

MILESTONE 4
 */

#include <avr/io.h>
#include<util/delay.h>
#include "Adc.h"
#include "GPIO.h"
#include "interrupt.h"
#include "PWM.h"
#include "PM_GpiO.h"
#include "PM_AdC.h"

#define SET_BIT(PORT,PIN) PORT|=(1<<PIN)
#define CLR_BIT(PORT,PIN) PORT&=~(1<<PIN)
#define read_bit(PORT,PIN) PORT & (1<<PIN)

volatile unsigned int suspension_pressure = 0;

int main(void)
{
    GPIO_setting_Init();



    void (*input)() = &inputs; // Function pointer of GPIO
    (*input)();
    void (*interrupt)() = &Switches; //Function Pointer of Interrupt
    (*interrupt)();
     void (*intensity)() = &HeadIntensity; // Function Pointer of PWM
     (*intensity)();
     void (*light)() = &adc; // Function Pointer of ADC
     (*light)();
    air_s.on=0; // Initial Position of Engine On Switch is off
    air_s.off=0; // Initial Position of Seat belt Switch is Off



    //Enable the Global interrupt
    Set_Bit(SREG,7);

    while(1)
    {
    ADCON; // enabling ADC
    void adc();
    adc_read(); // Start Conversion
     if(air_s.on == 1 && air_s.off==1)
     {
         Clr_Bit(PORTB,PB2);
         if(air_s.adc_value>0 && air_s.adc_value<200)
         {

             Clr_Bit(PORTB,PB5);
             Clr_Bit(PORTB,PB0);
         }
         else if(air_s.adc_value>=200 && air_s.adc_value<=400)
         {
             SetPWM(192);
             Set_Bit(PORTB,PB0);
             Clr_Bit(PORTB,PB5); // 75%
         }
         else
         {
             SetPWM(64);// 25%
             //Set_Bit(DDRD,PD3);
             _delay_ms(2000);
             Set_Bit(PORTB,PB5);
             Set_Bit(PORTB,PB0);
         }
     }
     else
     {   Clr_Bit(PORTB,PB5); // Tail Light OFF
         Clr_Bit(PORTB,PB0);
         Set_Bit(PORTB,PB2);
         SetPWM(0); // PWM Off or Head Light OFF
     }

      if((READ_BIT(PIND,PD2)))
            {
             adc3();
             adc_start3();

               if(adc_start3>0 && adc_start3<=300)
               {
                   Set_Bit(PORTD,PD7);

                   _delay_ms(200);
                   Clr_Bit(PORTD,PD7);

                }
               else if(adc_start3>300 && adc_start3<=750)
               {

                   Clr_Bit(PORTD,PD7);
               }
               else if(adc_start3>750 && adc_start3<=1024)
               {
                   Set_Bit(PORTD,PD7);

                   _delay_ms(1000);
                   Clr_Bit(PORTD,PD7);

               }


        }


     ADC_init();
    suspension_pressure = READ_ADC();//pressure sensor input

      if(suspension_pressure < 400)//low pressure
      {
          SET_BIT(PORTB,PB6);
          CLR_BIT(PORTB,PB7);
      }
      else if(suspension_pressure > 400 && suspension_pressure < 700)//ideal pressure
      {
          CLR_BIT(PORTB,PB6);
          CLR_BIT(PORTB,PB7);
      }
      else if(suspension_pressure > 700)//high pressure
      {
          CLR_BIT(PORTB,PB6);
          SET_BIT(PORTB,PB7);
      }

    }

    return 0;
}
ISR(PCINT1_vect) // Engine On Switch
{
 if(air_s.on==0)
 {
     air_s.on=1;
 }
 else
 {
   air_s.on=0;
 }
}
ISR(PCINT2_vect) // Engine OFF Switch
{
 if(air_s.off==0)
 {
    air_s.off=1;
 }
 else
 {
    air_s.off=0;
 }
}



